========== about the game ===========
Version: 0.2
Release: True
Date: 03/30/2021

========= about the author ==========
Feedback: mr.mirkly@gmail.com
Nick: Mirly

============== textures =============
I draw textures (Program: Photoshop CC-2020)

============ sound effects ==========
https://opengameart.org

============== music ================
ColdLake - https://www.youtube.com/watch?v=W-xWb2CQxX8